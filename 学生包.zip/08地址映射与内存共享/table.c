extern void	calc_mem();
int sys_table_mapping()
{
	unsigned long index_of_dir,  index_of_table;
	unsigned long entry;
	unsigned long page_table_base;
	unsigned long page_dir_base = 0;

	__asm("cli");
	
	calc_mem();	// 显示内存空闲页面数。
	
	// 首先打印输出页目录信息。格式为：Page Directory(页目录的物理页框号 | 所在线性地址)
	fprintk(1,"Page Directory(PFN:0x0 | LA:0x00000000)\n");
	
	// 第一层循环，遍历页目录中的所有 PDE
	for(index_of_dir = 0; index_of_dir < 1024; index_of_dir++)
	{
		entry = ((unsigned long*)page_dir_base)[index_of_dir];
		
		if(!(entry & 1))	/* 跳过无效的 PDE */
			continue;
		
		// 输出 PDE 信息,格式如下：  
		// PDE: 下标 -> Page Table(页表的物理页框号 | 所在的线性地址)
		fprintk(1,"\tPDE: 0x%X -> Page Table(PFN:0x%X | LA:0x%08X)\n", index_of_dir,  entry >> 12, 0xFFFFF000 & entry);

		/* 页目录项的高20位即为页表的物理地址，页表的物理地址即为页表的逻辑地址 */
		page_table_base = 0xFFFFF000 & entry;
		
		/* 第二层循环，遍历页表中的所有 PTE */
		for(index_of_table = 0; index_of_table < 1024; index_of_table++)
		{
			entry = ((unsigned long*)page_table_base)[index_of_table];
			
			if(!(entry & 1))	/* 跳过无效的 PTE */
				continue;	
			
			// 输出 PTE 信息，格式如下：
			// PTE: 下标 -> Physical Page(物理页框号 | 所在的线性地址)
			fprintk(1,"\t\tPTE: 0x%X -> Physical Page(PFN:0x%X | LA:0x%08X)\n", index_of_table, 
				entry >> 12, (index_of_dir << 22) | (index_of_table << 12));
		}
	 }
	__asm("sti");

	return 0;
}
